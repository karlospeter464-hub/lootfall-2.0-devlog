# Lootfall 2.0 — The Ember Trial

A small Godot 4.7 arena prototype. Open `project.godot` and press **F5**.

## Play

- **WASD:** move. **Mouse:** aim. **Hold left mouse button:** cast fireballs.
- Survive six waves. Clear every enemy to finish a wave.
- After waves 2 and 4, choose one of three upgrades. The same upgrade can be chosen twice.
- **Escape:** pause/resume. Upgrade and result buttons also support keyboard focus (Tab/arrows, Enter/Space).
- Death or clearing wave 6 opens the result screen. Start a new run from there.
- Best wave is remembered only while the game is running. Closing the game resets it.

The game uses original procedural placeholder graphics. There is no inventory, mana, loot, meta progression or external dependency in this prototype.

## Tune in the Inspector

- Select `Arena`: first-wave size, extra enemies per wave, active enemy cap, spawn interval, safe spawn distance, enemy health/speed/contact damage. Changes affect subsequent spawns.
- Select `Player`: movement speed, base health/damage/cast interval and contact protection. Base combat values are reapplied on a new run.
- Open `scenes/projectile.tscn`: fireball speed and lifetime.
- Six waves and upgrade events at waves 2/4 are fixed for this experiment.

## Verify

Using your Godot console executable, run from this project folder:

```powershell
$env:APPDATA = Join-Path (Get-Location) '.godot/test-user'
New-Item -ItemType Directory -Force -Path $env:APPDATA | Out-Null
& $godotExe --headless --path . --script res://tests/arena_test.gd
& $godotExe --headless --path . --quit-after 120
```

Set `$godotExe` to your local Godot console executable first. The test uses real scenes, physics/projectile hits, contact damage, wave progression, upgrade-button signals, pause input and restart. Its accelerated full-run check defeats enemies programmatically; it does not validate player difficulty or game feel.

To capture a **staged engine preview**, use:

```powershell
& $godotExe --path . --script res://tests/capture_preview.gd -- --output=C:/path/to/preview.png
```

Optional `--view=upgrade` or `--view=result` captures those screens. These images are reproducible test arrangements, not evidence of a human playthrough.

## Manual acceptance

Play a full run: check aiming while moving, fair enemy contact, visible power changes, both choices, pause/resume and restart after death/victory. Repeat at a different window size. Adjust difficulty from actual observations.

Development documentation and screenshots currently live separately at `C:/Users/elias/OneDrive/Dokumente/ChatGPT/Lootfall 2.0`. This project is at `C:/Users/elias/Lootfall 2.0/lootfall-2.0`.
